var U = { CEB_BACKEND_BASE_URL: "https://calendar-vlu.nhkhoa.site" };
const L = () => crypto.randomUUID(), i = (() => {
  const e = U.CEB_BACKEND_BASE_URL;
  if (e.startsWith("http://"))
    throw new Error(
      "[Background] Production build must use HTTPS for BACKEND_BASE_URL. Set CEB_BACKEND_BASE_URL to an HTTPS URL."
    );
  return e;
})(), b = (e) => {
  const o = e.headers.get("content-type");
  if (!(o != null && o.includes("application/json")))
    throw new Error("Server returned non-JSON response.");
}, h = "calendarvlu.googleSyncJob", I = 900 * 1e3, y = "calendarvlu.googleSyncProgress", f = "calendarvlu.googleLoginFlow", T = "calendarvlu.googleLoginNotice", R = 600 * 1e3;
function D(e) {
  if (!e || typeof e != "object") return !1;
  const o = e;
  if (o.type !== "GOOGLE_SYNC_START") return !1;
  const t = o.payload;
  return !t || typeof t != "object" || typeof t.calendarId != "string" || !t.calendarId || !Array.isArray(t.events) ? !1 : t.events.every(
    (n) => typeof n == "object" && n !== null && typeof n.summary == "string" && typeof n.startDate == "string" && typeof n.endDate == "string" && typeof n.startTime == "string" && typeof n.endTime == "string"
  );
}
function K(e) {
  return !e || typeof e != "object" ? !1 : e.type === "OPEN_OAUTH_TAB";
}
function J(e) {
  return !e || typeof e != "object" ? { valid: !1, error: "Message must be a non-null object" } : K(e) ? { valid: !0, data: e } : D(e) ? { valid: !0, data: e } : { valid: !1, error: `Unknown message type: ${e.type}` };
}
const _ = "calendarvlu-keepalive";
function $() {
  chrome.alarms.create(_, { periodInMinutes: 4 });
}
function A() {
  chrome.alarms.clear(_);
}
chrome.alarms.onAlarm.addListener((e) => {
  e.name === _ && chrome.storage.local.get(h).catch(() => {
  });
});
const M = "Đã kết nối Google Calendar thành công. Hãy mở online.vlu.edu.vn và đăng nhập VLU để lấy lịch.", Y = (e) => e instanceof Error && e.message.includes("Receiving end does not exist"), O = async (e, o) => {
  try {
    await chrome.runtime.sendMessage(e);
  } catch (t) {
    Y(t) || console.error(`[Background] Failed to broadcast ${o}:`, t);
  }
}, P = async () => (await chrome.storage.local.get(h))[h], x = async (e) => (await chrome.storage.local.get(`${y}:${e}`))[`${y}:${e}`], F = async (e, o) => {
  await chrome.storage.local.set({ [`${y}:${e}`]: o });
}, m = async (e) => {
  await chrome.storage.local.remove(`${y}:${e}`);
}, g = async (e) => {
  await chrome.storage.local.set({ [h]: e }), await O({ type: "GOOGLE_SYNC_STATE_CHANGED", job: e }, "sync state change");
}, j = (e) => (e == null ? void 0 : e.status) === "running" && typeof e.startedAt == "number" && Date.now() - e.startedAt < I, H = async () => (await chrome.storage.local.get(f))[f], V = (e) => (e == null ? void 0 : e.status) === "started" && Date.now() - e.startedAt < R, W = async (e) => {
  await chrome.storage.local.set({ [T]: e }), await O({ type: "GOOGLE_LOGIN_SUCCESS", notice: e }, "login success");
}, X = (e) => {
  if (!(e != null && e.startsWith(i))) return !1;
  try {
    return new URL(e).pathname === "/";
  } catch {
    return !1;
  }
}, q = async (e, o) => {
  var n;
  if (!(o != null && o.startsWith(i))) return;
  console.info("[Background][GoogleOAuth] Backend navigation detected", {
    tabId: e,
    url: o,
    backendBaseUrl: i
  });
  const t = await H();
  if (!t || !V(t)) {
    console.info("[Background][GoogleOAuth] No active login flow for backend navigation", {
      tabId: e,
      hasFlow: !!t,
      flowStartedAt: t == null ? void 0 : t.startedAt
    }), t && await chrome.storage.local.remove(f);
    return;
  }
  if (typeof t.tabId == "number" && t.tabId !== e) {
    console.info("[Background][GoogleOAuth] Ignoring backend navigation from non-login tab", {
      tabId: e,
      expectedTabId: t.tabId
    });
    return;
  }
  if (!X(o)) {
    console.info("[Background][GoogleOAuth] Waiting for OAuth return URL before checking status", {
      tabId: e,
      url: o
    });
    return;
  }
  try {
    const a = L();
    console.info("[Background][GoogleOAuth] Checking Google status after login", {
      tabId: e,
      requestId: a,
      statusUrl: `${i}/api/extension/google/status`
    });
    const l = await fetch(`${i}/api/extension/google/status`, {
      method: "GET",
      credentials: "include",
      headers: {
        "X-CalendarVLU-Client": "extension",
        "X-CalendarVLU-Request-Id": a
      }
    });
    b(l);
    const s = await l.json();
    if (console.info("[Background][GoogleOAuth] Status after login response", {
      requestId: a,
      httpStatus: l.status,
      ok: s.ok,
      connected: s.connected,
      hasSignInUrl: !!s.signInUrl,
      errorCode: (n = s.error) == null ? void 0 : n.code
    }), !l.ok || s.ok === !1 || !s.connected) return;
    const d = {
      status: "success",
      createdAt: Date.now(),
      message: M
    };
    await chrome.storage.local.remove(f), await W(d);
  } catch (a) {
    console.error("[Background] Google login status check failed (may retry):", a);
  }
}, Z = async () => {
  const e = `${i}/auth/sign-in?callbackUrl=/`;
  console.info("[Background][GoogleOAuth] Opening sign-in tab", {
    signInUrl: e,
    backendBaseUrl: i
  });
  const o = await chrome.tabs.create({ url: e });
  return await chrome.storage.local.set({
    [f]: {
      status: "started",
      startedAt: Date.now(),
      tabId: o.id
    }
  }), console.info("[Background][GoogleOAuth] Login flow stored", {
    tabId: o.id
  }), { ok: !0 };
}, v = 10, z = async (e) => {
  const o = await P();
  if (j(o))
    return { ok: !1, error: "SYNC_ALREADY_RUNNING", job: o };
  const t = {
    id: L(),
    status: "running",
    startedAt: Date.now(),
    calendarId: e.payload.calendarId,
    eventCount: e.payload.events.length
  };
  await g(t), $();
  try {
    let n = await x(t.id);
    n || (n = []);
    const a = e.payload.events.filter((c) => !n.includes(c.id || ""));
    if (a.length === 0) {
      const c = {
        ...t,
        status: "success",
        finishedAt: Date.now(),
        report: { created: 0, updated: 0, skipped: e.payload.events.length, failed: 0 }
      };
      return await g(c), await m(t.id), A(), { ok: !0, job: c };
    }
    const l = a;
    let s = 0, d = 0, S = n.length, E = 0;
    for (let c = 0; c < l.length; c += v) {
      const w = l.slice(c, c + v), G = await fetch(`${i}/api/extension/google/import`, {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
          "X-CalendarVLU-Client": "extension",
          "X-CalendarVLU-Request-Id": t.id
        },
        body: JSON.stringify({
          calendarId: e.payload.calendarId,
          events: w,
          options: { mode: "upsert", dryRun: !1 }
        })
      });
      b(G);
      let p;
      try {
        p = await G.json();
      } catch (r) {
        throw console.error("[Background] Invalid JSON from backend:", r), new Error("Phản hồi từ server không hợp lệ.");
      }
      if (!G.ok || p.ok === !1) {
        const r = p.error;
        throw new Error(
          typeof (r == null ? void 0 : r.message) == "string" ? r.message : typeof (r == null ? void 0 : r.code) == "string" ? r.code : "Không thể đồng bộ lên Google Calendar."
        );
      }
      const u = p.report;
      u && (s += u.created, d += u.updated, S += u.skipped, E += u.failed);
      const C = w.map((r) => r.id || "").filter(Boolean);
      n.push(...C), await F(t.id, n);
      const N = {
        ...t,
        status: "running",
        report: { created: s, updated: d, skipped: S, failed: E }
      };
      await g(N);
    }
    const B = {
      created: s,
      updated: d,
      skipped: S,
      failed: E
    }, k = {
      ...t,
      status: "success",
      finishedAt: Date.now(),
      report: B
    };
    return await g(k), await m(t.id), A(), { ok: !0, job: k };
  } catch (n) {
    const a = {
      ...t,
      status: "error",
      finishedAt: Date.now(),
      error: n instanceof Error ? n.message : "Không thể đồng bộ lên Google Calendar."
    };
    return await g(a), A(), { ok: !1, error: a.error, job: a };
  }
};
chrome.tabs.onUpdated.addListener((e, o, t) => {
  var n;
  o.url && ((n = t.url) != null && n.startsWith(i)) && O({ type: "BACKEND_NAVIGATION", url: t.url }, "backend navigation"), (o.url || o.status === "complete") && q(e, t.url).catch((a) => {
    console.error("[Background] Google login success check failed:", a);
  });
});
chrome.runtime.onMessage.addListener((e, o, t) => {
  const n = J(e);
  if (!n.valid)
    return console.error("[Background] Invalid message received:", n.error), t({ ok: !1, error: n.error }), !1;
  const a = n.data;
  return a.type === "OPEN_OAUTH_TAB" ? (Z().then(t), !0) : a.type === "GOOGLE_SYNC_START" ? (z(a).then(t), !0) : !1;
});
