var U = { CEB_BACKEND_BASE_URL: "https://calendar-vlu.nhkhoa.site" };
const C = () => crypto.randomUUID(), c = (() => {
  const e = U.CEB_BACKEND_BASE_URL;
  if (e.startsWith("http://"))
    throw new Error(
      "[Background] Production build must use HTTPS for BACKEND_BASE_URL. Set CEB_BACKEND_BASE_URL to an HTTPS URL."
    );
  return e;
})(), N = (e) => {
  const a = e.headers.get("content-type");
  if (!(a != null && a.includes("application/json")))
    throw new Error("Server returned non-JSON response.");
}, f = "calendarvlu.googleSyncJob", k = 900 * 1e3, h = "calendarvlu.googleSyncProgress", p = "calendarvlu.googleLoginFlow", R = "calendarvlu.googleLoginNotice", B = 600 * 1e3, D = (e) => {
  if (!e || typeof e != "object") return !1;
  const a = e;
  if (a.type !== "GOOGLE_SYNC_START") return !1;
  const t = a.payload;
  return !t || typeof t != "object" || typeof t.calendarId != "string" || !t.calendarId || !Array.isArray(t.events) ? !1 : t.events.every(
    (r) => typeof r == "object" && r !== null && typeof r.summary == "string" && typeof r.startDate == "string" && typeof r.endDate == "string" && typeof r.startTime == "string" && typeof r.endTime == "string"
  );
}, K = (e) => !e || typeof e != "object" ? !1 : e.type === "OPEN_OAUTH_TAB", J = (e) => !e || typeof e != "object" ? { valid: !1, error: "Message must be a non-null object" } : K(e) ? { valid: !0, data: e } : D(e) ? { valid: !0, data: e } : { valid: !1, error: `Unknown message type: ${e.type}` }, w = "calendarvlu-keepalive", M = () => {
  chrome.alarms.create(w, { periodInMinutes: 4 });
}, G = () => {
  chrome.alarms.clear(w);
};
chrome.alarms.onAlarm.addListener((e) => {
  e.name === w && chrome.storage.local.get(f).catch(() => {
  });
});
const Y = "Đã kết nối Google Calendar thành công. Hãy mở online.vlu.edu.vn và đăng nhập VLU để lấy lịch.", $ = (e) => e instanceof Error && e.message.includes("Receiving end does not exist"), A = async (e, a) => {
  try {
    await chrome.runtime.sendMessage(e);
  } catch (t) {
    $(t);
  }
}, P = async () => (await chrome.storage.local.get(f))[f], j = async (e) => (await chrome.storage.local.get(`${h}:${e}`))[`${h}:${e}`], x = async (e, a) => {
  await chrome.storage.local.set({ [`${h}:${e}`]: a });
}, O = async (e) => {
  await chrome.storage.local.remove(`${h}:${e}`);
}, u = async (e) => {
  await chrome.storage.local.set({ [f]: e }), await A({ type: "GOOGLE_SYNC_STATE_CHANGED", job: e });
}, H = (e) => (e == null ? void 0 : e.status) === "running" && typeof e.startedAt == "number" && Date.now() - e.startedAt < k, V = async () => (await chrome.storage.local.get(p))[p], F = (e) => (e == null ? void 0 : e.status) === "started" && Date.now() - e.startedAt < B, W = async (e) => {
  await chrome.storage.local.set({ [R]: e }), await A({ type: "GOOGLE_LOGIN_SUCCESS", notice: e });
}, X = (e) => {
  if (!(e != null && e.startsWith(c))) return !1;
  try {
    return new URL(e).pathname === "/";
  } catch {
    return !1;
  }
}, q = async (e, a) => {
  if (!(a != null && a.startsWith(c))) return;
  const t = await V();
  if (!t || !F(t)) {
    t && await chrome.storage.local.remove(p);
    return;
  }
  if (!(typeof t.tabId == "number" && t.tabId !== e) && X(a))
    try {
      const r = C(), o = await fetch(`${c}/api/extension/google/status`, {
        method: "GET",
        credentials: "include",
        headers: {
          "X-CalendarVLU-Client": "extension",
          "X-CalendarVLU-Request-Id": r
        }
      });
      N(o);
      const i = await o.json();
      if (!o.ok || i.ok === !1 || !i.connected) return;
      const l = {
        status: "success",
        createdAt: Date.now(),
        message: Y
      };
      await chrome.storage.local.remove(p), await W(l);
    } catch {
    }
}, Z = async () => {
  const e = `${c}/auth/sign-in?callbackUrl=/`, a = await chrome.tabs.create({ url: e });
  return await chrome.storage.local.set({
    [p]: {
      status: "started",
      startedAt: Date.now(),
      tabId: a.id
    }
  }), { ok: !0 };
}, v = 10, z = async (e) => {
  const a = await P();
  if (H(a))
    return { ok: !1, error: "SYNC_ALREADY_RUNNING", job: a };
  const t = {
    id: C(),
    status: "running",
    startedAt: Date.now(),
    calendarId: e.payload.calendarId,
    eventCount: e.payload.events.length
  };
  await u(t), M();
  try {
    let r = await j(t.id);
    r || (r = []);
    const o = e.payload.events.filter((s) => !r.includes(s.id || ""));
    if (o.length === 0) {
      const s = {
        ...t,
        status: "success",
        finishedAt: Date.now(),
        report: { created: 0, updated: 0, skipped: e.payload.events.length, failed: 0 }
      };
      return await u(s), await O(t.id), G(), { ok: !0, job: s };
    }
    const i = o;
    let l = 0, y = 0, E = r.length, _ = 0;
    for (let s = 0; s < i.length; s += v) {
      const L = i.slice(s, s + v), S = await fetch(`${c}/api/extension/google/import`, {
        method: "POST",
        credentials: "include",
        headers: {
          "Content-Type": "application/json",
          "X-CalendarVLU-Client": "extension",
          "X-CalendarVLU-Request-Id": t.id
        },
        body: JSON.stringify({
          calendarId: e.payload.calendarId,
          events: L,
          options: { mode: "upsert", dryRun: !1 }
        })
      });
      N(S);
      let g;
      try {
        g = await S.json();
      } catch {
        throw new Error("Phản hồi từ server không hợp lệ.");
      }
      if (!S.ok || g.ok === !1) {
        const n = g.error;
        throw new Error(
          typeof (n == null ? void 0 : n.message) == "string" ? n.message : typeof (n == null ? void 0 : n.code) == "string" ? n.code : "Không thể đồng bộ lên Google Calendar."
        );
      }
      const d = g.report;
      d && (l += d.created, y += d.updated, E += d.skipped, _ += d.failed);
      const I = L.map((n) => n.id || "").filter(Boolean);
      r.push(...I), await x(t.id, r);
      const T = {
        ...t,
        status: "running",
        report: { created: l, updated: y, skipped: E, failed: _ }
      };
      await u(T);
    }
    const b = {
      created: l,
      updated: y,
      skipped: E,
      failed: _
    }, m = {
      ...t,
      status: "success",
      finishedAt: Date.now(),
      report: b
    };
    return await u(m), await O(t.id), G(), { ok: !0, job: m };
  } catch (r) {
    const o = {
      ...t,
      status: "error",
      finishedAt: Date.now(),
      error: r instanceof Error ? r.message : "Không thể đồng bộ lên Google Calendar."
    };
    return await u(o), G(), { ok: !1, error: o.error, job: o };
  }
};
chrome.tabs.onUpdated.addListener((e, a, t) => {
  var r;
  a.url && ((r = t.url) != null && r.startsWith(c)) && A({ type: "BACKEND_NAVIGATION", url: t.url }), (a.url || a.status === "complete") && q(e, t.url).catch((o) => {
  });
});
chrome.runtime.onMessage.addListener((e, a, t) => {
  const r = J(e);
  if (!r.valid)
    return t({ ok: !1, error: r.error }), !1;
  const o = r.data;
  return o.type === "OPEN_OAUTH_TAB" ? (Z().then(t), !0) : o.type === "GOOGLE_SYNC_START" ? (z(o).then(t), !0) : !1;
});
